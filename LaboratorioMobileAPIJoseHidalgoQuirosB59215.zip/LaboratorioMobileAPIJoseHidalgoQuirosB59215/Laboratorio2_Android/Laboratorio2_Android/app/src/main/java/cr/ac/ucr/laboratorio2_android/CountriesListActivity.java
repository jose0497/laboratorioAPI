package cr.ac.ucr.laboratorio2_android;

import android.app.LauncherActivity;
import android.content.Context;
import android.nfc.Tag;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.util.Log;
import android.widget.Adapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import Interface.Covid19;
import adapters.CountriesListAdapter;
import adapters.StudentsListAdapter;
import models.Country;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class CountriesListActivity extends AppCompatActivity {

    public RecyclerView countries_list_recycler;
    public List<Country> countriesList = new ArrayList<>();
    public List<Country> countries = new ArrayList<>();
    public List<Country> aux = new ArrayList<>();
    LauncherActivity.ListItem listItem = new LauncherActivity.ListItem();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_countries_list);
        //listItem = (LauncherActivity.ListItem ) findViewById(R.id.cl_countries_list_item);
        getCountries();

    }

    //Conexión a BD o consumir WebAPI/WebService

    private void getCountries() {

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://api.covid19api.com/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        Covid19 covid19 = retrofit.create(Covid19.class);
        Call<List<Country>> call = covid19.getCountries();

        countries_list_recycler = findViewById(R.id.countries_list_recycler);
        CountriesListAdapter adapter = new CountriesListAdapter(countries, this);
        countries_list_recycler.setLayoutManager(new LinearLayoutManager(this));
        countries_list_recycler.setAdapter(adapter);
        final Context context = this;
        call.enqueue(new Callback<List<Country>>() {
            @Override
            public void onResponse(Call<List<Country>> call, Response<List<Country>> response) {
                if (!response.isSuccessful()) {
                    /*error en la respuesta*/
                }
                countries = response.body();
                countries_list_recycler.setAdapter(new CountriesListAdapter(countries, context));
            }

            @Override
            public void onFailure(Call<List<Country>> call, Throwable t) {

            }
        });
        List<Country> tempList = new ArrayList<>();
        tempList.add(new Country("CR"));



    }

    public void asd(List<Country> countries) {


        countries_list_recycler = findViewById(R.id.countries_list_recycler);
        CountriesListAdapter adapter = new CountriesListAdapter(countries, this);
        countries_list_recycler.setLayoutManager(new LinearLayoutManager(this));
        countries_list_recycler.setAdapter(adapter);
    }
}
