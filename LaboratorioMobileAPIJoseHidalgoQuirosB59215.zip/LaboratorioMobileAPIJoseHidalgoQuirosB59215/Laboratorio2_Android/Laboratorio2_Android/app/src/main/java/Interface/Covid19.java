package Interface;


import android.text.format.DateFormat;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import models.ByCountry;
import models.Country;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface Covid19 {
    Date date = new Date();


    @GET("countries")
    Call<List<Country>> getCountries();

    Date d = new Date();
    // CharSequence s  = DateFormat.format("MMMM d, yyyy ", d.getTime());
    SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
    String formattedDate = df.format(d.getTime());
    String strDate = String.valueOf(df.format(d));
    String str = "status/";
    String str2 = ":00:00Z";
    @GET("status/confirmed?from=") //i.e https://api.test.com/Search?
    Call<List<ByCountry>> getByCountry(@Query("date1") String date1, @Query("date2") String date2 );


}
