package cr.ac.ucr.laboratorio2_android;

import android.os.Bundle;
import android.text.format.DateFormat;
import android.util.Log;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import Interface.Covid19;
import models.ByCountry;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import java.util.Date;

public class ByCountryActivity extends AppCompatActivity {
    TextView textView;
    //TextView textView;
    private String country;
    public List<ByCountry> countryList = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.by_country);

        country = getIntent().getStringExtra("country");
        textView = (TextView)findViewById(R.id.tv_detail_country);

        this.getByCountry();

    }

    private void getByCountry(){
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://api.covid19api.com/country/"+country+"/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        Covid19 covid19 = retrofit.create(Covid19.class);
        Date d = new Date();
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        String formattedDate = df.format(d.getTime());
        String formattedDate2 = df.format(d.getTime());
        String actualDate = String.valueOf(df.format(d));
        String previusDate = String.valueOf(df.getCalendar().getTime().before(d));


        Call<List<ByCountry>> call = covid19.getByCountry(previusDate,actualDate);
        call.enqueue(new Callback<List<ByCountry>>() {
            public void onResponse(Call<List<ByCountry>> call, Response<List<ByCountry>> response) {
                if (!response.isSuccessful()) {                    
                    textView.setText("No response");
                }
                countryList = response.body();               

                int index = countryList.size()-1;
                textView.setText(

                        "Coutry: \n     "+countryList.get(index).getCountry() +"\n"+
                                "Lat: \n     "+ countryList.get(index).getLat() +"\n"+
                                "Lon: \n     "+ countryList.get(index).getLon() +"\n"+
                                "Cases: \n     "+countryList.get(index).getCases() +"\n"+
                                "Status: \n     "+ countryList.get(index).getStatus() +"\n"+
                                "Date: \n     "+ countryList.get(index).getDate());
                
            }
            @Override
            public void onFailure(Call<List<ByCountry>> call, Throwable t) {
                textView.setText("No response");
            }
        });
    }
}
