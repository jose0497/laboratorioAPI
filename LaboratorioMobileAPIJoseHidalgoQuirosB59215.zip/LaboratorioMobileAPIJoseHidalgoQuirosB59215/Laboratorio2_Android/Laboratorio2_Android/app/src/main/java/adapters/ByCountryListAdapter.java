package adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import cr.ac.ucr.laboratorio2_android.R;
import models.Country;

public class ByCountryListAdapter extends RecyclerView.Adapter<ByCountryListAdapter.CountryViewHolder>{

    private List<Country> countriesList;
    private Context context;

    public ByCountryListAdapter(List<Country> countriesList, Context context) {
        this.countriesList = countriesList;
        this.context = context;
    }

    @NonNull
    @Override
    public CountryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View listItem = inflater.inflate(R.layout.countries_list_item, parent, false);
        ByCountryListAdapter.CountryViewHolder viewHolder = new ByCountryListAdapter.CountryViewHolder(listItem);

        return viewHolder;

    }

    @Override
    public void onBindViewHolder(@NonNull CountryViewHolder holder, int position) {
        final Country country = countriesList.get(position);
        holder.name.setText(country.getCountry());

        holder.itemLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context, "El pais seleccionado es: "+country.getCountry(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return countriesList.size();
    }

    //View holder para lograr llenar el contenido de cada item
    public static class CountryViewHolder extends RecyclerView.ViewHolder {
        public TextView name;
        public ConstraintLayout itemLayout;

        public CountryViewHolder(@NonNull View itemView) {
            super(itemView);
            this.name = (TextView) itemView.findViewById(R.id.tv_name);
            this.itemLayout = (ConstraintLayout) itemView.findViewById(R.id.cl_countries_list_item);
        }
    }
}
