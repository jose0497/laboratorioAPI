package cr.ac.ucr.laboratorio2_android;

import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import Interface.Covid19;
import adapters.CountriesListAdapter;
import models.Country;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ByContryListActivity extends AppCompatActivity {

    public RecyclerView countries_list_recycler;
    public List<Country> countriesList = new ArrayList<>();
    public List<Country> countries = new ArrayList<>();
    public List<Country> aux = new ArrayList<>();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);



        Log.d("myTag", "This is my message");

        setContentView(R.layout.activity_countries_list);

        countries_list_recycler = findViewById(R.id.countries_list_recycler);
        countriesList = getCountries();

        CountriesListAdapter adapter = new CountriesListAdapter(countriesList, this);
        countries_list_recycler.setLayoutManager(new LinearLayoutManager(this));
        countries_list_recycler.setAdapter(adapter);

    }

    //Conexión a BD o consumir WebAPI/WebService

    private List<Country> getCountries() {

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://api.covid19api.com/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        Covid19 covid19 = retrofit.create(Covid19.class);
        Call<List<Country>> call = covid19.getCountries();
        call.enqueue(new Callback<List<Country>>() {
            @Override
            public void onResponse(Call<List<Country>> call, Response<List<Country>> response) {
                if (!response.isSuccessful()) {


                }
                countries = response.body();
                Log.i("myTag", "This is my message "+countries.get(0).getCountry());

            /*    for(Country country: countries) {
                    aux.add(new Country(country.getCountry()));
                }*/

                aux.add(new Country(countries.get(0).getCountry()));

            }

            @Override
            public void onFailure(Call<List<Country>> call, Throwable t) {

            }
        });
        //Log.i("myTag", "This is my message "+countries.get(0).getCountry());




        //Log.i("myTag", "This is my message "+this.countries.get(0).getCountry());
        List<Country> tempList = new ArrayList<>();
        tempList.add(new Country("CR"));


        return aux;
    }
}
